import { config } from 'dotenv';
config();

import '@/ai/flows/answer-event-questions.ts';